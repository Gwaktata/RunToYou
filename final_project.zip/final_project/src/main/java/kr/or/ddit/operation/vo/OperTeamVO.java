package kr.or.ddit.operation.vo;

import org.springframework.stereotype.Repository;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Repository
@Getter
@Setter
@ToString
public class OperTeamVO {
	
	private String maxRnum;
	private String rnum;
	private String empCd;
	private String secCd;
	private String empNm;
	private String position;
	private String empPic;
	private String stateCd;
	private String deptNm;
	private String secNm;
	private String major;
	private String duty;
	
}
