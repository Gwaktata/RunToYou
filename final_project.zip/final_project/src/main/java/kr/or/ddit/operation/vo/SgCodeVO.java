package kr.or.ddit.operation.vo;

import org.springframework.stereotype.Repository;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Repository
@Getter
@Setter
@ToString
public class SgCodeVO {
	private String sgCd;
	private String sgNm;
	private String sgAmt;
	private String jCls;
	private String zCls;
	private String sgOp1;
	private String sgOp2;
	
}
