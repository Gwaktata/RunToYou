package kr.or.ddit.reservation.vo;

import lombok.Data;

@Data
public class ReceptVO {

	private String rcptNo;
	private String rsvtNo;
	private String empCd;
	private String rcptDt;
	
	private String pntCd;
}
