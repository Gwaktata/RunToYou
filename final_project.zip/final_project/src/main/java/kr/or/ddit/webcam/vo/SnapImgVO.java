package kr.or.ddit.webcam.vo;

import lombok.Data;

@Data
public class SnapImgVO {
	private String uri;
	private String pntCd;
	
	private String treatCd;
	private int fileNo;
	private String fileNm;
	private String filePath;
	private String fileRegDt;
	private String empCd;
	private String fileCls;
}
