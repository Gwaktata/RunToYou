package kr.or.ddit.webcam.service;

import java.util.List;
import java.util.Map;

import kr.or.ddit.webcam.vo.SnapImgVO;

public interface SnapImgService {

	public int insertSnapImg(SnapImgVO vo);
	
	public List<SnapImgVO> snapLog(Map<String, String> map);
}
