package kr.or.ddit.login.vo;

public class UserAuth {
	//VW_USER_AUTH
	private String username;
	private String auth;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getAuth() {
		return auth;
	}
	public void setAuth(String auth) {
		this.auth = auth;
	}
	
	@Override
	public String toString() {
		return "UserAuth [username=" + username + ", auth=" + auth + "]";
	}
	
}
