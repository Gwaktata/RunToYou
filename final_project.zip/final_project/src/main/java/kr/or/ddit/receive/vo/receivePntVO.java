package kr.or.ddit.receive.vo;

import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
@Data
public class receivePntVO {
	
	private String pntCd;
	private String pntNm;
	private String pntHp;
	
	private List<receiveTrtVO> treatVO;
	
	
}
