package kr.or.ddit.receive.vo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Data
public class receiveTrtVO {
	
	private String treatCd;
	private String rcptNo;
	private String treatOp;
	private String treatDt;
	private String rcvCd;
	private String rcvDt;
	private int rcvAmt;
	private int nRcvAmt;
	private int rnum;
	
	
}
