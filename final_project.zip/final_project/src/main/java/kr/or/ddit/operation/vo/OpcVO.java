package kr.or.ddit.operation.vo;

import lombok.Data;

@Data
public class OpcVO {
	private String operCd;
	private int opcNo;
	private String opcCd;
	private String opcNm;
	private int opcAmt;
	
	
}
