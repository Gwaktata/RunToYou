select * from OPERATION

