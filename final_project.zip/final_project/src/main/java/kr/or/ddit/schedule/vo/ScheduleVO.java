package kr.or.ddit.schedule.vo;

import lombok.Data;

@Data
public class ScheduleVO {
	private int scdNo;
	private String empCd;
	private String scdNm;
	private String scdCont;
	private String scdStTime;
	private String scdEndTime;
}
