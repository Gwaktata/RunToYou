package kr.or.ddit.main.mapper;

import java.util.List;

import kr.or.ddit.main.vo.SearchDataVO;

public interface MainMapper {
	public List<SearchDataVO> searchEpr(String data);
}
