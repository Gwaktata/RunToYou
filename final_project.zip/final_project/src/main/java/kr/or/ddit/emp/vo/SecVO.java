package kr.or.ddit.emp.vo;

import org.springframework.stereotype.Repository;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
@Data
@Repository
public class SecVO {
	
	private String secCd;
	
	private String secNm;
	
	private int empCnt;
	
	private String newDeptNm;
	
	private String oldDeptNm;
}
