package kr.or.ddit.patients.vo;

import lombok.Data;

@Data
public class PatientsEmpVO {

	private String empCd;	//직원코드
	private String empNm;	//직원명
	private String major;	//과목
}
