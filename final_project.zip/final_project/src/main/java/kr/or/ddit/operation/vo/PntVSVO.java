package kr.or.ddit.operation.vo;

import org.springframework.stereotype.Repository;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Repository
@Getter
@Setter
@ToString
public class PntVSVO {
	private String pntCd;
	private String vsDt;
	private String vsBpMax;
	private String vsTmp;
	private String vsBpMin;
	private String vsBs;
	private String ddate;
	
}
