package kr.or.ddit.ent.vo;

import lombok.Data;

@Data
public class RoomVO {
	
	private int wardCls;
	private int roomCls;
	private int bed;
	private String bedOrder;
	private String pntCd;
	private String pntNm;
	private String entDt;
	private String levDt;
	private int ingBed;
	private String allBed;
}
