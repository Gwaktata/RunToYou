package kr.or.ddit.operation.vo;

import lombok.Data;

@Data
public class TreatVO {
	private String treatCd;
    private String treatOp;
    private String pntCd;
    private String pntNm;
    
    private String disCd;
    private int digCls;
    private String disNm;
    
}
