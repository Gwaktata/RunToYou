package kr.or.ddit.operation.vo;

import lombok.Data;

@Data
public class operationRoomVO {
	private int opRoomNo;
	private String OpRoomState;
}
