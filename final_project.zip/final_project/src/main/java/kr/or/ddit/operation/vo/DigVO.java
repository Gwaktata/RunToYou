package kr.or.ddit.operation.vo;

import lombok.Data;

@Data
public class DigVO {
	private String disCd;
	private int digCls;
	private String treatCd;
	private String disNm;
}
