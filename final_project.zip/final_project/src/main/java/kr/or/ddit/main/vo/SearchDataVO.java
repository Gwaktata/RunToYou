package kr.or.ddit.main.vo;

import lombok.Data;

@Data
public class SearchDataVO {
	private String nm;
	private String cd;
	private String cls;
}
